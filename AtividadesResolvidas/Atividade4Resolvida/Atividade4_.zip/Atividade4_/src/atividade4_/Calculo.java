
package atividade4_;

public interface Calculo {
    public Double calculoImposto();
    public void descricao(); 
}


